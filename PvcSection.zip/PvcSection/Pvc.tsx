
 
import  Create  from './components/CreateGameVsComp'
import ResolvedGames from './components/Resolved'


const Pvc = () => {
  return (
    <>
    <Create/>
    <ResolvedGames/>
 
    </>
  )
}

export default Pvc